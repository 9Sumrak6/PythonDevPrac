Client
======
**Client** is an implementation of client.

.. automodule:: mood.client
   :members: