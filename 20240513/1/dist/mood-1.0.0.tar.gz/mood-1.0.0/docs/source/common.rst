Common
======
**Common** is a module with common functions, variables and etc.

.. automodule:: mood.common
   :members: