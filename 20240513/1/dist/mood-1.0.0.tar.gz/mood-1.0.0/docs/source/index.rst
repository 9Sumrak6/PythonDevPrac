.. Server documentation master file, created by
   sphinx-quickstart on Fri Apr 12 20:34:48 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Mood's documentation!
==================================
**Mood** is PVE multi-user game. Here playes can add monsters, attack them and move around the field. Moreover, u can communicate with other players ang negotiate with them to attack the monsters together.

.. tip::
    `Link <https://sphinx-ru.readthedocs.io/archive/rst-markup.html#listing-rst>`_ to the used project documentation

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   server
   client
   common

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
